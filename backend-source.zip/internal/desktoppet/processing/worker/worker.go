// SPDX-FileCopyrightText: 2026 彭旭
// SPDX-License-Identifier: AGPL-3.0-only
package worker

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/u-ai/backend/internal/desktoppet"
	"github.com/u-ai/backend/internal/desktoppet/contracts"
	"github.com/u-ai/backend/internal/desktoppet/processing"
	"github.com/u-ai/backend/internal/desktoppet/processing/application"
	"github.com/u-ai/backend/internal/desktoppet/processing/source"
	"github.com/u-ai/backend/internal/desktoppet/taskstate"
	"github.com/u-ai/backend/log"
	_ "golang.org/x/image/webp"
	"gorm.io/gorm"
)

const (
	processingLeaseDuration     = 10 * time.Minute
	processingHeartbeatInterval = 30 * time.Second
	processingPollInterval      = 5 * time.Second
	processingWorkerID          = "processing-worker-1"
	processingTimeFormat        = "2006-01-02 15:04:05"
	defaultBackgroundMode       = "remove_background"
	defaultLoopType             = "loop"
	maxConcurrentProcessingTasks = 2
)

type Worker struct {
	db                *gorm.DB
	repo              processing.Repository
	validator         *processing.Validator
	pipeline          *application.Pipeline
	sourceResolver    *application.RepoSourceResolver
	previewGenerator  *processing.PreviewGenerator
	cleanupManager    *processing.CleanupManager
	dataDir           string
	stopCh            chan struct{}
	wg                sync.WaitGroup
	sem               chan struct{}
	stateEngine       *taskstate.Engine
	revisionPaths     map[string]string
	onActionProcessed func(taskID, actionID, actionKey string)
	revisionPromoter  func(processingTaskID, actionKey, userID string) error
}

func NewWorker(db *gorm.DB, repo processing.Repository, dataDir string, pipeline *application.Pipeline, sourceResolver *application.RepoSourceResolver) *Worker {
	stateStore := desktoppet.NewStateStore(db)

	return &Worker{
		db:               db,
		repo:             repo,
		validator:        processing.NewValidator(repo, dataDir),
		pipeline:         pipeline,
		sourceResolver:   sourceResolver,
		previewGenerator: processing.NewPreviewGenerator(dataDir),
		cleanupManager:   processing.NewCleanupManager(dataDir),
		dataDir:          dataDir,
		stopCh:           make(chan struct{}),
		sem:              make(chan struct{}, maxConcurrentProcessingTasks),
		stateEngine:      taskstate.NewEngine(stateStore),
		revisionPaths:    make(map[string]string),
	}
}

func (w *Worker) SetOnActionProcessed(fn func(taskID, actionID, actionKey string)) {
	w.onActionProcessed = fn
}

func (w *Worker) SetRevisionPromoter(fn func(processingTaskID, actionKey, userID string) error) {
	w.revisionPromoter = fn
}

func (w *Worker) Start(ctx context.Context) {
	w.recoverStuckTasks(ctx)
	w.wg.Add(1)
	go w.run(ctx)
}

func (w *Worker) Stop() {
	close(w.stopCh)
	w.wg.Wait()
}

func (w *Worker) run(ctx context.Context) {
	defer w.wg.Done()
	ticker := time.NewTicker(processingPollInterval)
	defer ticker.Stop()
	for {
		select {
		case <-w.stopCh:
			return
		case <-ctx.Done():
			return
		case <-ticker.C:
			w.pollAndProcess(ctx)
		}
	}
}

func (w *Worker) pollAndProcess(ctx context.Context) {
	tasks, err := w.repo.ListQueuedProcessingTasks()
	if err != nil {
		log.Logger.Errorf("processing worker poll tasks failed: %v", err)
		return
	}
	if len(tasks) == 0 {
		return
	}
	for i := range tasks {
		select {
		case <-w.stopCh:
			return
		case <-ctx.Done():
			return
		case w.sem <- struct{}{}:
		}
		task := tasks[i]
		w.wg.Add(1)
		go func() {
			defer w.wg.Done()
			defer func() { <-w.sem }()
			w.processTask(ctx, &task)
		}()
	}
}

func (w *Worker) processTask(ctx context.Context, task *processing.ProcessingTask) {
	executionID := "processing-" + uuid.New().String()
	leaseExpiresAt := time.Now().Add(processingLeaseDuration).Format(processingTimeFormat)
	now := time.Now().Format(processingTimeFormat)
	progress := ProgressValidatingSources

	_, err := w.stateEngine.Transition(ctx, taskstate.TransitionRequest{
		EntityType:      contracts.EntityProcessingTask,
		EntityID:        task.ID,
		From:            []contracts.LifecycleStatus{contracts.StatusQueued},
		To:              contracts.StatusProcessing,
		Stage:           contracts.StageValidatingSources,
		Reason:          contracts.ReasonProcessingTaskClaim,
		ActorType:       contracts.ActorWorker,
		ActorID:         processingWorkerID,
		ExecutionID:     executionID,
		WorkerID:        processingWorkerID,
		LeaseExpiresAt:  leaseExpiresAt,
		LastHeartbeatAt: now,
		Progress:        &progress,
		NeedOwnership:   false,
	})
	if err != nil {
		if taskstate.IsConflictError(err) {
			return
		}
		log.Logger.Errorf("claim processing task %s failed: %v", task.ID, err)
		return
	}
	log.Logger.Infof("processing worker claimed task %s (execution=%s)", task.ID, executionID)

	w.publishProgress(task.ID, ProgressValidatingSources, StageValidatingSources)

	processingCtx, processingCancel := context.WithCancel(ctx)
	defer processingCancel()

	heartbeatCtx, heartbeatCancel := context.WithCancel(processingCtx)
	w.startHeartbeat(heartbeatCtx, task.ID, executionID, processingCancel)
	defer heartbeatCancel()

	genTask, err := w.repo.GetGenerationTask(task.GenerationTaskID)
	if err != nil {
		log.Logger.Errorf("get generation task %s failed: %v", task.GenerationTaskID, err)
		w.finalizeTask(task.ID, err, executionID)
		return
	}

	processErr := w.runProcessingStages(processingCtx, task, genTask.UserID, executionID)

	w.finalizeTask(task.ID, processErr, executionID)
}

func (w *Worker) runProcessingStages(ctx context.Context, task *processing.ProcessingTask, userID string, executionID string) error {
	w.updateStage(task.ID, executionID, StageValidatingSources, ProgressValidatingSources)
	sourceVal, err := w.validator.ValidateSources(task.GenerationTaskID, userID)
	if err != nil {
		return err
	}

	actions, err := w.repo.ListProcessingActionsOrdered(task.ID)
	if err != nil {
		return fmt.Errorf("list processing actions failed: %w", err)
	}
	if len(actions) == 0 {
		return fmt.Errorf("no actions to process")
	}

	seenKeys := make(map[string]bool, len(actions))
	for _, a := range actions {
		if seenKeys[a.ActionKey] {
			return fmt.Errorf("duplicate action key: %s", a.ActionKey)
		}
		seenKeys[a.ActionKey] = true
	}

	totalActions := len(actions)
	succeededActionKeys := make([]string, 0, totalActions)
	for i := range actions {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if w.isCancelled(task.ID) {
			break
		}

		taskProgress := ProgressValidatingSources + (ProgressPreview-ProgressValidatingSources)*i/totalActions
		w.updateProgress(task.ID, executionID, taskProgress)

		action := &actions[i]
		if err := w.processAction(ctx, task, action, sourceVal, executionID); err != nil {
			log.Logger.Errorf("processing action %s failed: %v", action.ActionKey, err)
			w.failAction(action, err)
			continue
		}
		succeededActionKeys = append(succeededActionKeys, action.ActionKey)
	}

	if w.isCancelled(task.ID) {
		return fmt.Errorf("cancelled")
	}

	w.updateStage(task.ID, executionID, StagePreview, ProgressPreview)

	if w.revisionPromoter != nil && len(succeededActionKeys) > 0 {
		for _, actionKey := range succeededActionKeys {
			if err := w.revisionPromoter(task.ID, actionKey, userID); err != nil {
				log.Logger.Errorf("promote revision for action %s failed: %v", actionKey, err)
			}
		}
	}

	w.updateStage(task.ID, executionID, StagePackaging, ProgressManifest)
	if err := w.buildPackage(task, sourceVal); err != nil {
		log.Logger.Errorf("build package for task %s failed: %v", task.ID, err)
		return err
	}

	w.updateProgress(task.ID, executionID, ProgressPackage)
	return nil
}

func (w *Worker) processAction(ctx context.Context, task *processing.ProcessingTask, action *processing.ProcessingAction, sourceVal *processing.SourceValidationResult, executionID string) error {
	w.publishActionEvent(task.ID, action.ActionKey, "started")

	tx := w.db.Begin()
	if tx.Error != nil {
		return fmt.Errorf("begin transaction for attempt failed: %w", tx.Error)
	}
	attempt, err := w.repo.BeginProcessingActionAttempt(tx, action.ID, action.RowVersion, executionID, action.SourceAttemptNumber)
	if err != nil {
		tx.Rollback()
		return fmt.Errorf("begin processing action attempt failed: %w", err)
	}
	if err := tx.Commit().Error; err != nil {
		return fmt.Errorf("commit attempt creation failed: %w", err)
	}

	configSnapshot := application.BuildConfigSnapshot(task)

	resolveReq := source.ResolveRequest{
		ProcessingTaskID:   task.ID,
		ProcessingActionID: action.ID,
		ActionKey:          action.ActionKey,
		GenerationTaskID:   task.GenerationTaskID,
		UserID:             sourceVal.Task.UserID,
		SourceAttemptID:    attempt.ID,
		CandidateIndex:     0,
		DataDir:            w.dataDir,
	}
	sourceDesc, err := w.sourceResolver.Resolve(ctx, resolveReq)
	if err != nil {
		return fmt.Errorf("resolve source descriptor failed: %w", err)
	}

	w.updateActionProgress(action, StageBackgroundRemoval, ProgressBackgroundRemoval)

	pipelineReq := application.ProcessActionRequest{
		Context:            ctx,
		SourceDescriptor:   sourceDesc,
		ConfigSnapshot:     configSnapshot,
		ProcessingTaskID:   task.ID,
		ProcessingActionID: action.ID,
		ActionKey:          action.ActionKey,
		GenerationTaskID:   task.GenerationTaskID,
		ExecutionID:        executionID,
		ProcessingVersion:  task.ProcessingVersion,
	}
	result, err := w.pipeline.ProcessAction(pipelineReq)
	if err != nil {
		return fmt.Errorf("pipeline process action failed: %w", err)
	}

	w.updateActionProgress(action, StageWriteFrames, ProgressWriteFrames)
	if err := w.persistRevision(task, action, result, attempt, executionID); err != nil {
		log.Logger.Errorf("persist revision for action %s failed: %v", action.ActionKey, err)
	}
	if err := w.persistProcessedFrames(task, action, sourceVal, result, attempt, executionID); err != nil {
		log.Logger.Errorf("persist processed frames for action %s failed: %v", action.ActionKey, err)
	}

	w.updateActionProgress(action, StageActionJSON, ProgressActionJSON)
	if err := w.writeActionJSON(task, action, result.FrameCount); err != nil {
		return fmt.Errorf("write action json failed: %w", err)
	}

	w.updateActionProgress(action, StagePreview, ProgressPreview)
	previewImgs, err := w.loadRevisionFrames(result.RootRelativePath)
	if err != nil {
		return fmt.Errorf("load revision frames for preview failed: %w", err)
	}
	if _, err := w.previewGenerator.GenerateActionPreview(task.GenerationTaskID, task.ProcessingVersion, action.ActionKey, previewImgs); err != nil {
		return fmt.Errorf("generate action preview failed: %w", err)
	}

	if err := w.publishFramesToActionDir(task, action, result.RootRelativePath); err != nil {
		log.Logger.Errorf("publish frames to action dir for %s failed: %v", action.ActionKey, err)
	}

	w.revisionPaths[action.ActionKey] = result.RootRelativePath

	w.succeedAction(action)

	if w.onActionProcessed != nil {
		w.onActionProcessed(task.ID, action.ID, action.ActionKey)
	}

	return nil
}

func (w *Worker) writeActionJSON(task *processing.ProcessingTask, action *processing.ProcessingAction, frameCount int) error {
	fps := action.FPS
	if fps <= 0 {
		fps = task.DefaultFPS
	}
	loopType := action.LoopType
	if action.PlaybackMode == "loop" || action.PlaybackMode == "ping_pong" {
		loopType = "loop"
	} else if action.PlaybackMode == "once" || action.PlaybackMode == "hold" {
		loopType = "once"
	}
	anchor := processing.DefaultAnchorForActionKey(action.ActionKey)
	actionJSON := processing.BuildActionJSON(action.ActionKey, action.ActionNameSnapshot, frameCount, fps, anchor, loopType)
	processing.EnrichActionJSONFromSpec(actionJSON, action)

	actionsDir := filepath.Join(w.dataDir, "desktop-pets", "generation-tasks", task.GenerationTaskID, "processed",
		fmt.Sprintf("version-%d", task.ProcessingVersion), "actions", action.ActionKey)
	if err := os.MkdirAll(actionsDir, 0755); err != nil {
		return fmt.Errorf("create actions dir failed: %w", err)
	}

	finalPath := filepath.Join(actionsDir, "action.json")
	tmpPath := filepath.Join(actionsDir, ".action.json.tmp")

	data, err := json.MarshalIndent(actionJSON, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal action json failed: %w", err)
	}

	if err := os.WriteFile(tmpPath, data, 0644); err != nil {
		return fmt.Errorf("write tmp action json failed: %w", err)
	}

	if err := os.Rename(tmpPath, finalPath); err != nil {
		os.Remove(tmpPath)
		return fmt.Errorf("rename action json failed: %w", err)
	}

	return nil
}

func (w *Worker) loadRevisionFrames(rootRelPath string) ([]image.Image, error) {
	dir := filepath.Join(w.dataDir, rootRelPath, "frames")

	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].Name() < entries[j].Name()
	})

	frames := make([]image.Image, 0, len(entries))
	for _, entry := range entries {
		if entry.IsDir() || strings.HasPrefix(entry.Name(), ".") {
			continue
		}
		f, err := os.Open(filepath.Join(dir, entry.Name()))
		if err != nil {
			return nil, err
		}
		img, _, err := image.Decode(f)
		f.Close()
		if err != nil {
			return nil, err
		}
		frames = append(frames, img)
	}
	return frames, nil
}

func (w *Worker) buildPackage(task *processing.ProcessingTask, sourceVal *processing.SourceValidationResult) error {
	selector := processing.NewDefaultActionSelector("")
	defaultAction, err := selector.SelectDefaultAction(sourceVal.SucceededActions)
	if err != nil {
		return fmt.Errorf("select default action failed: %w", err)
	}

	processingActions, err := w.repo.ListProcessingActions(task.ID)
	if err != nil {
		return fmt.Errorf("list processing actions failed: %w", err)
	}

	includedActions := make([]string, 0, len(processingActions))
	for _, pa := range processingActions {
		if pa.Status == "succeeded" && pa.Excluded == 0 {
			includedActions = append(includedActions, pa.ActionKey)
		}
	}

	if len(includedActions) == 0 {
		return fmt.Errorf("no succeeded actions to package")
	}

	defaultIdleFrames, err := w.loadProcessedFrames(defaultAction)
	if err != nil {
		return fmt.Errorf("load default idle frames failed: %w", err)
	}

	if _, err := w.previewGenerator.GeneratePackagePreview(task.GenerationTaskID, task.ProcessingVersion, defaultIdleFrames); err != nil {
		return fmt.Errorf("generate package preview failed: %w", err)
	}

	packager := processing.NewPackager(w.repo, w.dataDir)
	req := &processing.PackageBuildRequest{
		ProcessingTaskID:  task.ID,
		UserID:            sourceVal.Task.UserID,
		CharacterID:       sourceVal.Task.CharacterID,
		GenerationTaskID:  task.GenerationTaskID,
		PackageName:       sourceVal.Task.Name,
		DefaultAction:     defaultAction,
		IncludedActions:   includedActions,
		CanvasWidth:       task.OutputWidth,
		CanvasHeight:      task.OutputHeight,
		ProcessingVersion: task.ProcessingVersion,
		SucceededActions:  sourceVal.SucceededActions,
	}

	result, err := packager.BuildPackage(req)
	if err != nil {
		return fmt.Errorf("build package failed: %w", err)
	}

	_, err = w.stateEngine.Transition(context.Background(), taskstate.TransitionRequest{
		EntityType: contracts.EntityPackage,
		EntityID:   result.Package.ID,
		From:       []contracts.LifecycleStatus{contracts.StatusPending},
		To:         contracts.StatusProcessing,
		Stage:      contracts.StageCommitting,
		Reason:     contracts.ReasonPackageFinalizeSuccess,
		ActorType:  contracts.ActorWorker,
		ActorID:    processingWorkerID,
	})
	if err != nil {
		log.Logger.Errorf("package %s transition to processing failed: %v", result.Package.ID, err)
	}

	_, err = w.stateEngine.Transition(context.Background(), taskstate.TransitionRequest{
		EntityType: contracts.EntityPackage,
		EntityID:   result.Package.ID,
		From:       []contracts.LifecycleStatus{contracts.StatusProcessing},
		To:         contracts.StatusSucceeded,
		Stage:      contracts.StageCompleted,
		Reason:     contracts.ReasonPackageFinalizeSuccess,
		ActorType:  contracts.ActorWorker,
		ActorID:    processingWorkerID,
	})
	if err != nil {
		log.Logger.Errorf("package %s transition to succeeded failed: %v", result.Package.ID, err)
	}

	if err := w.repo.UpdatePackageStatus(result.Package.ID, map[string]interface{}{
		"status":     "ready",
		"updated_at": time.Now().Format(processingTimeFormat),
	}); err != nil {
		log.Logger.Errorf("update package %s status to ready failed: %v", result.Package.ID, err)
	}

	return nil
}

func (w *Worker) loadProcessedFrames(actionKey string) ([]image.Image, error) {
	rootRelPath, ok := w.revisionPaths[actionKey]
	if !ok {
		return nil, fmt.Errorf("revision path not found for action %s", actionKey)
	}
	return w.loadRevisionFrames(rootRelPath)
}

func (w *Worker) publishFramesToActionDir(task *processing.ProcessingTask, action *processing.ProcessingAction, rootRelPath string) error {
	srcFramesDir := filepath.Join(w.dataDir, rootRelPath, "frames")
	entries, err := os.ReadDir(srcFramesDir)
	if err != nil {
		return fmt.Errorf("read source frames dir: %w", err)
	}

	dstFramesDir := filepath.Join(w.dataDir, "desktop-pets", "generation-tasks", task.GenerationTaskID,
		"processed", fmt.Sprintf("version-%d", task.ProcessingVersion), "actions", action.ActionKey, "frames")
	if err := os.MkdirAll(dstFramesDir, 0755); err != nil {
		return fmt.Errorf("create dst frames dir: %w", err)
	}

	for _, entry := range entries {
		if entry.IsDir() || strings.HasPrefix(entry.Name(), ".") {
			continue
		}
		src := filepath.Join(srcFramesDir, entry.Name())
		dst := filepath.Join(dstFramesDir, entry.Name())
		if err := copyFileEntry(src, dst); err != nil {
			return fmt.Errorf("copy frame %s: %w", entry.Name(), err)
		}
	}
	return nil
}

func copyFileEntry(src, dst string) error {
	data, err := os.ReadFile(src)
	if err != nil {
		return err
	}
	return os.WriteFile(dst, data, 0644)
}

func (w *Worker) persistProcessedFrames(
	task *processing.ProcessingTask,
	action *processing.ProcessingAction,
	sourceVal *processing.SourceValidationResult,
	result *application.ProcessActionResult,
	attempt *processing.ProcessingActionAttempt,
	executionID string,
) error {
	if result == nil || result.Manifest == nil || result.FrameCount == 0 {
		return nil
	}

	frameInfos := sourceVal.FramePaths[action.ActionKey]

	now := time.Now().Format(processingTimeFormat)
	frames := make([]processing.ProcessedFrame, 0, result.FrameCount)

	for i := 0; i < result.FrameCount; i++ {
		processedPath := filepath.ToSlash(filepath.Join(
			result.RootRelativePath, "frames", fmt.Sprintf("frame_%04d.png", i),
		))

		var sourceFrameID string
		var sourcePath string
		if i < len(frameInfos) {
			sourceFrameID = frameInfos[i].Frame.ID
			sourcePath = frameInfos[i].Frame.ResultImagePath
		}

		var contentHash string
		if i < len(result.Manifest.Frames) {
			contentHash = result.Manifest.Frames[i].FileHash
		}

		frames = append(frames, processing.ProcessedFrame{
			ID:                      "pf-" + uuid.New().String(),
			ProcessingActionID:      action.ID,
			FrameIndex:              i,
			SourceFrameID:           sourceFrameID,
			SourcePath:              sourcePath,
			ProcessedPath:           processedPath,
			Status:                  "succeeded",
			Width:                   task.OutputWidth,
			Height:                  task.OutputHeight,
			ContentHash:             contentHash,
			ProcessingAttemptID:     attempt.ID,
			ProcessingAttemptNumber: attempt.AttemptNumber,
			ExecutionID:             executionID,
			RevisionID:              result.RevisionID,
			CreatedAt:               now,
			UpdatedAt:               now,
		})
	}

	if err := w.repo.CreateProcessedFrames(w.db, frames); err != nil {
		return fmt.Errorf("create processed frames failed: %w", err)
	}
	return nil
}

func (w *Worker) persistRevision(
	task *processing.ProcessingTask,
	action *processing.ProcessingAction,
	result *application.ProcessActionResult,
	attempt *processing.ProcessingActionAttempt,
	executionID string,
) error {
	if result == nil || result.Manifest == nil || result.FrameCount == 0 {
		return nil
	}

	now := time.Now().Format(processingTimeFormat)
	revisionNumber := action.NextRevisionNumber
	if revisionNumber <= 0 {
		revisionNumber = 1
	}

	configSnapshotJSON := ""
	if result.SequenceMeasurement != nil {
		if data, err := json.Marshal(result.SequenceMeasurement.ProcessingReport); err == nil {
			configSnapshotJSON = string(data)
		}
	}

	rev := &processing.ProcessingRevision{
		ID:                 result.RevisionID,
		ProcessingTaskID:   task.ID,
		ProcessingActionID: action.ID,
		RevisionNumber:     revisionNumber,
		SourceAttemptID:    attempt.ID,
		SourceCandidateIdx: 0,
		Status:             "files_published",
		ConfigSnapshot:     configSnapshotJSON,
		ConfigHash:         result.Manifest.ConfigHash,
		PipelineVersion:    result.Manifest.PipelineVersion,
		FrameCount:         result.FrameCount,
		RootRelativePath:   result.RootRelativePath,
		RevisionHash:       result.Manifest.RevisionHash,
		Active:             0,
		CreatedAt:          now,
		UpdatedAt:          now,
	}

	tx := w.db.Begin()
	if tx.Error != nil {
		return fmt.Errorf("begin revision transaction failed: %w", tx.Error)
	}

	if err := w.repo.CreateProcessingRevision(tx, rev); err != nil {
		tx.Rollback()
		return fmt.Errorf("create revision record failed: %w", err)
	}

	artifactRecords := make([]processing.ProcessingArtifactRecord, 0, result.FrameCount*2)
	for i := 0; i < result.FrameCount; i++ {
		frameIdx := i
		fileHash := ""
		pixelHash := ""
		if i < len(result.Manifest.Frames) {
			fileHash = result.Manifest.Frames[i].FileHash
			pixelHash = result.Manifest.Frames[i].PixelHash
		}
		artifactRecords = append(artifactRecords, processing.ProcessingArtifactRecord{
			ID:           "art-" + uuid.New().String(),
			RevisionID:   result.RevisionID,
			FrameIndex:   &frameIdx,
			ArtifactKind: "frame",
			Stage:        "encode",
			RelativePath: filepath.ToSlash(filepath.Join(result.RootRelativePath, "frames", fmt.Sprintf("frame_%04d.png", i))),
			MimeType:     "image/png",
			Width:        task.OutputWidth,
			Height:       task.OutputHeight,
			ContentHash:  fileHash,
			MetadataJSON: fmt.Sprintf(`{"pixelHash":"%s"}`, pixelHash),
			CreatedAt:    now,
		})

		if i < len(result.Manifest.Frames) && result.Manifest.Frames[i].Mask != "" {
			artifactRecords = append(artifactRecords, processing.ProcessingArtifactRecord{
				ID:           "art-" + uuid.New().String(),
				RevisionID:   result.RevisionID,
				FrameIndex:   &frameIdx,
				ArtifactKind: "mask",
				Stage:        "background",
				RelativePath: filepath.ToSlash(filepath.Join(result.RootRelativePath, result.Manifest.Frames[i].Mask)),
				MimeType:     "image/png",
				Width:        task.OutputWidth,
				Height:       task.OutputHeight,
				CreatedAt:    now,
			})
		}
	}

	manifestArtifact := processing.ProcessingArtifactRecord{
		ID:           "art-" + uuid.New().String(),
		RevisionID:   result.RevisionID,
		ArtifactKind: "manifest",
		Stage:        "publish",
		RelativePath: filepath.ToSlash(filepath.Join(result.RootRelativePath, "revision.json")),
		MimeType:     "application/json",
		ByteSize:     int64(len(result.Manifest.RevisionHash)),
		ContentHash:  result.Manifest.RevisionHash,
		CreatedAt:    now,
	}
	artifactRecords = append(artifactRecords, manifestArtifact)

	if err := w.repo.CreateProcessingArtifacts(tx, artifactRecords); err != nil {
		tx.Rollback()
		return fmt.Errorf("create artifact records failed: %w", err)
	}

	measurementRecords := make([]processing.FrameMeasurementRecord, 0, len(result.Measurements))
	for _, m := range result.Measurements {
		subjectBoxJSON, _ := json.Marshal(m.SubjectBox)
		sourceAnchorJSON, _ := json.Marshal(m.SourceAnchor)
		targetAnchorJSON, _ := json.Marshal(m.TargetAnchor)
		edgeContactJSON, _ := json.Marshal(m.EdgeContact)
		clippingJSON, _ := json.Marshal(m.Clipping)
		trajectoryJSON, _ := json.Marshal(m.Trajectory)
		fullJSON, _ := m.ToJSON()

		measurementRecords = append(measurementRecords, processing.FrameMeasurementRecord{
			ID:                       "meas-" + uuid.New().String(),
			RevisionID:               result.RevisionID,
			FrameIndex:               m.FrameIndex,
			MeasurementSchemaVersion: 1,
			SubjectBoxJSON:           string(subjectBoxJSON),
			SourceAnchorJSON:         string(sourceAnchorJSON),
			TargetAnchorJSON:         string(targetAnchorJSON),
			AlphaCoverage:            m.AlphaCoverage,
			ComponentCount:           m.ComponentCount,
			EdgeContactJSON:          string(edgeContactJSON),
			ClippingJSON:             string(clippingJSON),
			TrajectoryJSON:           string(trajectoryJSON),
			MeasurementJSON:          fullJSON,
			CreatedAt:                now,
			UpdatedAt:                now,
		})
	}

	if err := w.repo.CreateFrameMeasurements(tx, measurementRecords); err != nil {
		tx.Rollback()
		return fmt.Errorf("create measurement records failed: %w", err)
	}

	if err := w.repo.ActivateRevision(tx, action.ID, result.RevisionID); err != nil {
		tx.Rollback()
		return fmt.Errorf("activate revision failed: %w", err)
	}

	if err := tx.Commit().Error; err != nil {
		return fmt.Errorf("commit revision transaction failed: %w", err)
	}

	return nil
}

func computeFileSHA256(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:]), nil
}

func (w *Worker) startHeartbeat(ctx context.Context, taskID, executionID string, leaseLostCancel context.CancelFunc) {
	w.wg.Add(1)
	go func() {
		defer w.wg.Done()
		ticker := time.NewTicker(processingHeartbeatInterval)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-w.stopCh:
				return
			case <-ticker.C:
				now := time.Now().Format(processingTimeFormat)
				lease := time.Now().Add(processingLeaseDuration).Format(processingTimeFormat)
				ok, err := w.repo.RefreshProcessingLeaseOwned(taskID, executionID, lease, now)
				if err != nil {
					log.Logger.Errorf("refresh processing lease task %s failed: %v", taskID, err)
					continue
				}
				if !ok {
					log.Logger.Warnf("processing lease lost for task %s, stopping heartbeat", taskID)
					_, tErr := w.stateEngine.Transition(context.Background(), taskstate.TransitionRequest{
						EntityType:    contracts.EntityProcessingTask,
						EntityID:      taskID,
						From:          []contracts.LifecycleStatus{contracts.StatusProcessing},
						To:            contracts.StatusQueued,
						Stage:         contracts.StageQueued,
						Reason:        contracts.ReasonWorkerLeaseLost,
						ActorType:     contracts.ActorWorker,
						ActorID:       processingWorkerID,
						ExecutionID:   executionID,
						NeedOwnership: true,
					})
					if tErr != nil {
						log.Logger.Errorf("requeue processing task %s after lease lost failed: %v", taskID, tErr)
					}
					leaseLostCancel()
					return
				}
			}
		}
	}()
}

func (w *Worker) updateStage(taskID, executionID, stage string, progress int) {
	now := time.Now().Format(processingTimeFormat)
	owned, _ := w.repo.UpdateProcessingTaskOwned(taskID, executionID, map[string]interface{}{
		"current_stage": stage,
		"progress":      progress,
		"updated_at":    now,
	})
	if !owned {
		log.Logger.Warnf("processing task %s ownership lost during updateStage", taskID)
		return
	}
	w.publishProgress(taskID, progress, stage)
}

func (w *Worker) updateProgress(taskID, executionID string, progress int) {
	now := time.Now().Format(processingTimeFormat)
	owned, _ := w.repo.UpdateProcessingTaskOwned(taskID, executionID, map[string]interface{}{
		"progress":   progress,
		"updated_at": now,
	})
	if !owned {
		log.Logger.Warnf("processing task %s ownership lost during updateProgress", taskID)
		return
	}
	w.publishProgress(taskID, progress, "")
}

func (w *Worker) updateActionProgress(action *processing.ProcessingAction, stage string, progress int) {
	now := time.Now().Format(processingTimeFormat)
	_ = w.repo.UpdateProcessingActionNoTx(action.ID, map[string]interface{}{
		"progress":   progress,
		"updated_at": now,
	})
	w.publishActionProgress(action.ProcessingTaskID, action.ActionKey, stage, progress)
}

func (w *Worker) succeedAction(action *processing.ProcessingAction) {
	now := time.Now().Format(processingTimeFormat)
	_ = w.repo.UpdateProcessingActionNoTx(action.ID, map[string]interface{}{
		"status":       "succeeded",
		"progress":     100,
		"completed_at": now,
		"updated_at":   now,
	})
	w.publishActionEvent(action.ProcessingTaskID, action.ActionKey, "succeeded")
}

func (w *Worker) failAction(action *processing.ProcessingAction, err error) {
	now := time.Now().Format(processingTimeFormat)
	errMsg := ""
	if err != nil {
		errMsg = err.Error()
	}
	_ = w.repo.UpdateProcessingActionNoTx(action.ID, map[string]interface{}{
		"status":        "failed",
		"progress":      100,
		"error_message": errMsg,
		"completed_at":  now,
		"updated_at":    now,
	})
	w.publishActionEvent(action.ProcessingTaskID, action.ActionKey, "failed")
}

func (w *Worker) isCancelled(taskID string) bool {
	task, err := w.repo.GetProcessingTask(taskID)
	if err != nil || task == nil {
		return false
	}
	return task.CancelRequestedAt != ""
}

func (w *Worker) finalizeTask(taskID string, processErr error, executionID string) {
	task, err := w.repo.GetProcessingTask(taskID)
	if err != nil {
		log.Logger.Errorf("get processing task for finalize failed: %v", err)
		return
	}

	defer func() {
		if err := w.cleanupManager.CleanupTempDir(task.GenerationTaskID); err != nil {
			log.Logger.Errorf("cleanup temp dir for task %s failed: %v", task.GenerationTaskID, err)
		}
	}()

	actions, err := w.repo.ListProcessingActions(taskID)
	if err != nil {
		log.Logger.Errorf("list processing actions for finalize failed: %v", err)
		actions = nil
	}

	succeeded, failed, hasActiveChildren := 0, 0, false
	for _, a := range actions {
		switch a.Status {
		case "succeeded":
			succeeded++
		case "failed":
			failed++
		case "processing", "queued":
			hasActiveChildren = true
		}
	}
	total := len(actions)

	snapshot := w.buildProcessingSnapshot(task, actions, succeeded, hasActiveChildren)
	decision := taskstate.AggregateProcessingTask(snapshot)

	if processErr != nil && decision.Status == contracts.StatusFailed {
		decision.ErrorMessage = processErr.Error()
	}

	currentStatus := contracts.LifecycleStatus(task.Status)

	if decision.Status == currentStatus && !currentStatus.IsTerminal() {
		w.publishCompleted(taskID, string(decision.Status), succeeded, failed, total)
		return
	}

	req := taskstate.TransitionRequest{
		EntityType:    contracts.EntityProcessingTask,
		EntityID:      taskID,
		From:          []contracts.LifecycleStatus{currentStatus},
		To:            decision.Status,
		Stage:         decision.Stage,
		Reason:        decision.Reason,
		ActorType:     contracts.ActorFinalizer,
		ActorID:       processingWorkerID,
		ExecutionID:   executionID,
		Progress:      &decision.Progress,
		ErrorCode:     decision.ErrorCode,
		ErrorMessage:  decision.ErrorMessage,
		FailureStage:  decision.FailureStage,
		NeedOwnership: true,
	}

	_, err = w.stateEngine.Transition(context.Background(), req)
	if err != nil {
		if taskstate.IsOwnershipLostError(err) {
			log.Logger.Warnf("processing task %s ownership lost during finalize", taskID)
			return
		}
		log.Logger.Errorf("finalize processing task %s failed: %v", taskID, err)
		return
	}

	w.publishCompleted(taskID, string(decision.Status), succeeded, failed, total)
}

func (w *Worker) buildProcessingSnapshot(task *processing.ProcessingTask, actions []processing.ProcessingAction, succeeded int, hasActiveChildren bool) taskstate.ProcessingSnapshot {
	total := len(actions)
	allActionsSucceeded := total > 0 && succeeded == total
	hasAtLeastOneSucceeded := succeeded > 0

	pkg, pkgErr := w.repo.GetPackageByProcessingTaskID(task.ID)
	packageExists := pkgErr == nil && pkg != nil
	packageReady := false
	packagePathValid := false
	manifestValid := false
	hashValid := false
	includedActionsMatch := false

	if packageExists {
		packageReady = pkg.Status == "succeeded" || pkg.Status == "ready"
		packagePathValid = pkg.PackagePath != "" && pathExists(filepath.Join(w.dataDir, pkg.PackagePath))
		manifestValid = pkg.ManifestPath != "" && fileExists(filepath.Join(w.dataDir, pkg.ManifestPath))
		hashValid = pkg.PackageHash != ""
		includedActionsMatch = checkIncludedActionsMatch(pkg.IncludedActions, actions)
	}

	cancelRequested := task.CancelRequestedAt != ""
	actualProgress := task.Progress
	if actualProgress == 0 {
		actualProgress = 100
	}

	return taskstate.ProcessingSnapshot{
		TaskStatus:                   contracts.LifecycleStatus(task.Status),
		CancelRequested:              cancelRequested,
		HasActiveChildren:            hasActiveChildren,
		AllActionsSucceeded:          allActionsSucceeded,
		HasAtLeastOneActionSucceeded: hasAtLeastOneSucceeded,
		PackageExists:                packageExists,
		PackageReady:                 packageReady,
		PackagePathValid:             packagePathValid,
		ManifestValid:                manifestValid,
		HashValid:                    hashValid,
		IncludedActionsMatch:         includedActionsMatch,
		AllowPartialResult:           true,
		ActualProgress:               actualProgress,
	}
}

func checkIncludedActionsMatch(includedActionsJSON string, actions []processing.ProcessingAction) bool {
	var included []string
	if err := json.Unmarshal([]byte(includedActionsJSON), &included); err != nil {
		return false
	}
	if len(included) == 0 {
		return false
	}
	includedSet := make(map[string]bool, len(included))
	for _, key := range included {
		includedSet[key] = true
	}
	for _, a := range actions {
		if a.Excluded == 1 {
			continue
		}
		if a.Status == "succeeded" {
			if !includedSet[a.ActionKey] {
				return false
			}
		}
	}
	return true
}

func fileExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && !info.IsDir()
}

func pathExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.IsDir()
}

func (w *Worker) recoverStuckTasks(ctx context.Context) {
	tasks, err := w.repo.ListRecoverableProcessingTasks()
	if err != nil {
		log.Logger.Errorf("list recoverable processing tasks failed: %v", err)
		return
	}
	for _, task := range tasks {
		if ctx.Err() != nil {
			return
		}
		_, err := w.stateEngine.Transition(ctx, taskstate.TransitionRequest{
			EntityType:    contracts.EntityProcessingTask,
			EntityID:      task.ID,
			From:          []contracts.LifecycleStatus{contracts.StatusProcessing},
			To:            contracts.StatusQueued,
			Stage:         contracts.StageQueued,
			Reason:        contracts.ReasonSystemLeaseExpired,
			ActorType:     contracts.ActorRecovery,
			ExecutionID:   task.ExecutionID,
			NeedOwnership: true,
		})
		if err != nil {
			if taskstate.IsConflictError(err) {
				continue
			}
			log.Logger.Errorf("recover processing task %s failed: %v", task.ID, err)
			continue
		}
		log.Logger.Infof("recovered processing task: %s", task.ID)

		actions, aErr := w.repo.ListProcessingActions(task.ID)
		if aErr != nil {
			log.Logger.Errorf("list processing actions for recovery %s failed: %v", task.ID, aErr)
			continue
		}
		for _, action := range actions {
			if action.Status == "processing" || action.Status == "queued" {
				if rErr := w.repo.ResetProcessingActionToPending(action.ID); rErr != nil {
					log.Logger.Errorf("reset processing action %s to pending failed: %v", action.ID, rErr)
				}
			}
		}
	}
}
