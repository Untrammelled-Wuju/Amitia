// SPDX-FileCopyrightText: 2026 彭旭
// SPDX-License-Identifier: AGPL-3.0-only
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/u-ai/backend/config"

	"github.com/u-ai/backend/internal/belief"
	"github.com/u-ai/backend/internal/character"
	"github.com/u-ai/backend/internal/chat"
	"github.com/u-ai/backend/internal/companion"
	"github.com/u-ai/backend/internal/decision"
	"github.com/u-ai/backend/internal/delivery"
	"github.com/u-ai/backend/internal/desktoppet"
	"github.com/u-ai/backend/internal/desktoppet/behavior"
	"github.com/u-ai/backend/internal/desktoppet/behavior/events"
	"github.com/u-ai/backend/internal/desktoppet/behavior/wiring"
	"github.com/u-ai/backend/internal/desktoppet/editing"
	"github.com/u-ai/backend/internal/desktoppet/installation"
	"github.com/u-ai/backend/internal/desktoppet/processing"
	"github.com/u-ai/backend/internal/desktoppet/processing/application"
	processingworker "github.com/u-ai/backend/internal/desktoppet/processing/worker"
	"github.com/u-ai/backend/internal/imageprovider/backgroundremoval"
	"github.com/u-ai/backend/internal/imageprovider/backgroundremoval/local"
	"github.com/u-ai/backend/internal/desktoppet/quality"
	"github.com/u-ai/backend/internal/desktoppet/quality/bridge"
	qualityworker "github.com/u-ai/backend/internal/desktoppet/quality/worker"
	"github.com/u-ai/backend/internal/desktoppet/quality/detectors"
	"github.com/u-ai/backend/internal/desktoppet/runtime"
	"github.com/u-ai/backend/internal/desktoppet/worker"
	"github.com/u-ai/backend/internal/emote"
	"github.com/u-ai/backend/internal/episodic"
	"github.com/u-ai/backend/internal/extension"
	"github.com/u-ai/backend/internal/extension/kernel"
	"github.com/u-ai/backend/internal/extension/kernel/event"
	"github.com/u-ai/backend/internal/graph"
	"github.com/u-ai/backend/internal/interaction"
	"github.com/u-ai/backend/internal/mcp"
	mcpauth "github.com/u-ai/backend/internal/mcp/auth"
	mcpclient "github.com/u-ai/backend/internal/mcp/client"
	mcpdependency "github.com/u-ai/backend/internal/mcp/dependency"
	mcpdiscovery "github.com/u-ai/backend/internal/mcp/discovery"
	mcpfeatures "github.com/u-ai/backend/internal/mcp/features"
	mcphost "github.com/u-ai/backend/internal/mcp/host"
	mcpmanager "github.com/u-ai/backend/internal/mcp/manager"
	"github.com/u-ai/backend/internal/mcp/protocol"
	mcpskill "github.com/u-ai/backend/internal/mcp/skill"
	"github.com/u-ai/backend/internal/memory"
	"github.com/u-ai/backend/internal/mindruntime"
	newoutbox "github.com/u-ai/backend/internal/outbox"
	"github.com/u-ai/backend/internal/personality"
	"github.com/u-ai/backend/internal/profile"
	"github.com/u-ai/backend/internal/psyche"
	"github.com/u-ai/backend/internal/psyche/appraisal"
	"github.com/u-ai/backend/internal/psyche/budget"
	"github.com/u-ai/backend/internal/qdrant"
	"github.com/u-ai/backend/internal/queue"
	"github.com/u-ai/backend/internal/safety"
	"github.com/u-ai/backend/internal/temporal"
	"github.com/u-ai/backend/internal/vision"
	"github.com/u-ai/backend/internal/worldbook"
	"github.com/u-ai/backend/log"
	"github.com/u-ai/backend/pkg/app"
)

type AppServices struct {
	DeliveryStore       *delivery.SQLiteDeliveryStore
	ChatDeliveryAdapter chat.DeliveryStore
	DeliveryWorker      *delivery.Worker
	Graph               graph.Service
	Memory              memory.Service
	Profile             profile.Service
	Episodic            episodic.Service
	WorldBook           worldbook.Service
	Vision              vision.Service
	Companion           companion.Service
	Chat                chat.Service
	UnifiedEntry        *interaction.UnifiedEntry
	DataLifecycle       *mindruntime.DataLifecycleCoordinator
	RuntimeQueue        *queue.SQLiteRuntimeQueueStore
	NewOutbox           *newoutbox.SQLiteOutboxStore
	OutboxWorker        *newoutbox.Worker
	DesktopPetWorker    *worker.Worker
	ProcessingWorker    *processingworker.Worker
	QualityService      quality.QualityService
	QualityWorker       *qualityworker.Worker
	InstallationService installation.Service
	ReleaseService     installation.ReleaseService
	DesktopPetRuntime  *runtime.Service
	EditingService     editing.Service
	BehaviorService    *behavior.BehaviorService
	Reconciliation      *mindruntime.ReconciliationEngine
	CircuitBreakers     *mindruntime.CircuitBreakerRegistry
	VoiceEntry          *interaction.VoiceEntry
	Extension           *extension.Runtime
	KernelContainer     *kernel.Container
	Emote               *emote.Service
	Temporal            *temporal.Service
	RelTimeCoordinator  *temporal.RelationshipTimeCoordinator
	MCPRepository       *mcp.Repository
	MCPConnections      *mcpmanager.Manager
	MCPAuth             *mcpauth.Manager
	MCPDiscovery        *mcpdiscovery.Service
	MCPSkills           *mcpskill.Runtime
	MCPSecrets          mcpauth.SecretStore
	MCPFeatures         *mcpfeatures.Service
	MCPHost             *mcphost.Service
	MCPInteractions     *mcphost.Broker
	MCPDependencies     *mcpdependency.Service
}

type defaultCharacterProvider struct {
	repo character.Repository
}

func (p *defaultCharacterProvider) GetDefaultCharacterID(ctx context.Context) (string, error) {
	profile, err := p.repo.GetRuntimeProfile("")
	if err != nil {
		return "", err
	}
	return profile.CharacterID, nil
}

type reflectionMemoryServiceAdapter struct {
	memory memory.Service
}

func (a reflectionMemoryServiceAdapter) CreateReflectionMemory(req interaction.ReflectionMemoryCreateRequest) error {
	_, err := a.memory.Create(&memory.CreateMemoryRequest{
		CharacterID:           req.CharacterID,
		MemoryType:            req.MemoryType,
		Key:                   req.Key,
		Value:                 req.Value,
		Importance:            req.Importance,
		Confidence:            req.Confidence,
		SourceMsgID:           req.SourceMsgID,
		SourceConvID:          req.SourceConvID,
		VerifiedStatus:        req.VerifiedStatus,
		Source:                req.Source,
		SensitivityLevel:      req.SensitivityLevel,
		AllowProactiveMention: req.AllowProactiveMention,
		RequiresConfirmation:  req.RequiresConfirmation,
		Scope:                 req.Scope,
	})
	return err
}

func NewAppServices(ctx *app.AppContext, graphSvc graph.Service) *AppServices {
	temporalSvc := temporal.NewService(temporal.NewRepository(ctx.DB), temporal.SystemClock{})
	relTimeRepo := temporal.NewRelationshipTimeRepository(ctx.DB, temporal.SystemClock{})
	relTimeCoordinator := temporal.NewRelationshipTimeCoordinator(relTimeRepo, temporal.SystemClock{})
	temporalSvc.SetRelationshipTimeProvider(relTimeCoordinator)
	memRepo := memory.NewRepository(ctx)
	memSvc := memory.NewService(memRepo, ctx, graphSvc)
	profRepo := profile.NewRepository(ctx)
	profSvc := profile.NewService(profRepo, ctx, graphSvc)
	epiRepo := episodic.NewRepository(ctx)
	epiSvc := episodic.NewService(epiRepo, ctx, graphSvc)
	wbRepo := worldbook.NewRepository(ctx)
	wbSvc := worldbook.NewService(wbRepo, ctx, graphSvc)
	visionRepo := vision.NewRepository(ctx.DB)
	visionSvc := vision.NewService(visionRepo)
	compSvc := companion.NewService(ctx)
	compSvc.AttachTemporalResolver(temporalSvc)
	if temporalSvc.FeatureFlags().RelationshipTimeEnabled {
		compSvc.AttachAssistantContactRecorder(relTimeCoordinator)
	}
	compressor := chat.NewCompressor(ctx.DB)
	psycheStore := psyche.NewSQLitePsycheStore(ctx.DB)
	if err := psycheStore.InitSchema(); err != nil {
		log.Error("failed to init psyche store schema:", err)
		panic("failed to init psyche store schema")
	}
	if err := ctx.DB.AutoMigrate(&chat.RelationshipStateRecord{}, &chat.NeedStateRecord{}); err != nil {
		log.Error("failed to init relationship/need store schema:", err)
		panic("failed to init relationship/need store schema")
	}
	chatSvc := chat.NewService(chat.NewRepository(ctx), ctx, memSvc, profSvc, epiSvc, wbSvc, compressor, visionSvc, graphSvc, psycheStore)
	extensionRuntime, err := extension.NewRuntimeWithOptions(context.Background(), ctx.DB, "1.0.0", extension.RuntimeOptions{SkipPluginManagerStart: true})
	if err != nil {
		log.Error("failed to initialize skill runtime:", err)
		panic("failed to initialize skill runtime")
	}
	kernelRoot := filepath.Join(os.TempDir(), "amitia-extension-kernel")
	if config.AppCfg != nil && config.AppCfg.Storage.DataDir != "" {
		kernelRoot = filepath.Join(config.AppCfg.Storage.DataDir, "extensions-v2")
	}
	if err := extensionRuntime.AttachKernel(kernelRoot); err != nil {
		log.Error("failed to initialize extension kernel:", err)
		panic("failed to initialize extension kernel")
	}
	kernelDBPath := filepath.Join(kernelRoot, "kernel.db")
	charRepo := character.NewRepository(ctx)
	kernelCharReader := newKernelCharacterReader(charRepo)
	kernelConvReader := newKernelConversationReader(chatSvc)
	kernelMemQuerySvc := newKernelMemoryQueryService(memSvc)
	kernelContainer, err := kernel.NewContainerBuilder().
		WithDBPath(kernelDBPath).
		WithExtensionRoot(kernelRoot).
		WithCharacterReader(kernelCharReader).
		WithConversationReader(kernelConvReader).
		WithMemoryQueryService(kernelMemQuerySvc).
		Build(context.Background())
	if err != nil {
		log.Error("failed to initialize kernel container:", err)
		panic("failed to initialize kernel container")
	}
	extensionRuntime.Kernel.SetContainer(kernelContainer)
	if err := extensionRuntime.Kernel.RecoverPackageOperations(context.Background()); err != nil {
		log.Error("package operation recovery failed: ", err)
		panic("failed to recover package operations")
	}
	if err := kernelContainer.Recover(context.Background()); err != nil {
		log.Warn("kernel recovery warning: ", err)
	}
	if kernelContainer.UpdateRecoveryManager != nil {
		recoveryActions, err := kernelContainer.UpdateRecoveryManager.ScanOnStartup(context.Background())
		if err != nil {
			log.Warn("update recovery scan warning: ", err)
		}
		for _, action := range recoveryActions {
			if err := kernelContainer.UpdateRecoveryManager.ExecuteRecovery(context.Background(), action); err != nil {
				log.Warn(fmt.Sprintf("update recovery execute failed for %s: %v", action.OperationID, err))
			} else {
				log.Info(fmt.Sprintf("update recovery completed for %s (strategy: %s)", action.OperationID, action.Strategy))
			}
		}
	}
	if kernelContainer.TaskRuntimeService != nil {
		if err := kernelContainer.TaskRuntimeService.StartupRecovery(context.Background()); err != nil {
			log.Warn("task runtime recovery warning: ", err)
		}
		kernelContainer.TaskRuntimeService.Start(context.Background())
	}
	if kernelContainer.EventService != nil {
		if err := kernelContainer.EventService.Start(context.Background()); err != nil {
			log.Error("event service start failed: ", err)
			panic("failed to start event service")
		}
	}
	if kernelContainer.ScheduleService != nil {
		if err := kernelContainer.ScheduleService.Start(context.Background()); err != nil {
			log.Error("schedule service start failed: ", err)
			panic("failed to start schedule service")
		}
	}
	kernelProxy := extension.NewKernelLifecycleProxy(extensionRuntime.Kernel)
	if err := extensionRuntime.Packages.AttachKernelProxy(kernelProxy); err != nil {
		log.Error("extension package recovery failed: ", err)
		panic("failed to recover extension package operations")
	}
	legacyReport, legacyErr := extensionRuntime.Packages.DetectLegacyPackages(context.Background())
	if legacyErr != nil {
		log.Warn("legacy extension package detection failed: ", legacyErr)
	} else if legacyReport.PendingManual > 0 {
		log.Warn(fmt.Sprintf("legacy extension packages require manual migration: %d pending (total %d, completed %d)", legacyReport.PendingManual, legacyReport.Total, legacyReport.Completed))
		for _, extID := range legacyReport.PendingExtensions {
			log.Warn(fmt.Sprintf("legacy extension pending manual migration: %s", extID))
		}
	} else {
		log.Info(fmt.Sprintf("legacy extension migration status: %d completed (total %d)", legacyReport.Completed, legacyReport.Total))
	}
	artifactMaintenance, err := kernel.NewPackageArtifactMaintenanceForStore(kernelContainer.PackageRepository, kernelContainer.PackageArtifactStore, kernel.DefaultPackageArtifactMaintenanceConfig())
	if err != nil {
		log.Error("failed to initialize package artifact maintenance: ", err)
		panic("failed to initialize package artifact maintenance")
	}
	kernelContainer.ArtifactMaintenance = artifactMaintenance
	if err := artifactMaintenance.Start(context.Background()); err != nil {
		log.Error("failed to start package artifact maintenance: ", err)
		panic("failed to start package artifact maintenance")
	}
	if extensionRuntime.Lifecycle != nil {
		extensionRuntime.Lifecycle.AttachKernelProxy(kernelProxy)
	}
	toolFacade := kernel.NewToolFacade(
		kernelContainer.ToolRegistry,
		kernelContainer.ExecutionKernel,
		kernel.DefaultToolFacadeConfig(),
	)
	toolFacade.SetAgentSkillCatalog(kernelContainer.AgentSkillCatalog)
	kernelContainer.ToolFacade = toolFacade
	chatSvc.SetToolRuntime(newChatToolRuntimeAdapter(toolFacade))
	if kernelContainer.DevConsoleService != nil {
		kernelContainer.DevConsoleService.SetToolFacadeProvider(toolFacade.Counters())
		kernelContainer.DevConsoleService.SetLegacyCallProvider(kernel.GlobalLegacyCallCounter())
	}
	if kernelContainer.HookService != nil {
		toolFacade.SetHookService(kernelContainer.HookService)
		chatSvc.SetHookInvoker(chat.NewHookAdapter(kernelContainer.HookService))
	}
	extensionRuntime.Workshop.SetModelGenerator(chatSvc)
	orchCfg := interaction.DefaultOrchestratorConfig()
	tracker := interaction.NewSQLiteInteractionTracker(ctx.DB)
	if err := tracker.InitSchema(); err != nil {
		log.Error("failed to init interaction tracker schema:", err)
		panic("failed to init interaction tracker schema")
	}
	newOutboxStore := newoutbox.NewSQLiteOutboxStore(ctx.DB, newoutbox.DefaultOutboxStoreConfig())
	if err := ctx.DB.AutoMigrate(&newoutbox.OutboxRecordModel{}, &newoutbox.DeadLetterRecordModel{}); err != nil {
		log.Error("failed to init outbox store schema:", err)
		panic("failed to init outbox store schema")
	}
	runtimeQueue := queue.NewSQLiteRuntimeQueueStore(ctx.DB)
	deliveryStore := delivery.NewSQLiteDeliveryStore(ctx.DB)
	deliveryWorker := delivery.NewWorker(deliveryStore, []delivery.ChannelAdapter{
		delivery.NewWebChannelAdapter(),
		delivery.NewQQChannelAdapter("http://127.0.0.1:19877"),
		delivery.NewWechatChannelAdapter("http://127.0.0.1:19876"),
	}, delivery.DefaultWorkerConfig())
	deliveryAdapter := &chatDeliveryAdapter{store: deliveryStore}
	chatSvc.SetDeliveryStore(deliveryAdapter)
	emoteSvc := emote.NewService(ctx.DB, deliveryStore)
	emoteDecision := emote.NewDecisionService(emoteSvc)
	chat.RegisterMessagePlanningHook(emoteDecision.Plan)

	outboxAdapter := &chatOutboxAdapter{store: newOutboxStore}
	chatSvc.SetOutboxStore(outboxAdapter)
	if err := runtimeQueue.InitSchema(); err != nil {
		log.Error("failed to init runtime queue schema:", err)
		panic("failed to init runtime queue schema")
	}

	dispatchedPublisher := newoutbox.NewDispatchedPublisher(newoutbox.LogOnlyPublisher())
	postProcessAdapter := &postProcessPublisherAdapter{chatSvc: chatSvc}
	dispatchedPublisher.Register("postprocess.pipeline.execute", postProcessAdapter)
	dispatchedPublisher.Register("postprocess.context.trim", postProcessAdapter)
	dispatchedPublisher.Register("postprocess.mood.recovery", postProcessAdapter)
	dispatchedPublisher.Register("postprocess.compressor.maybe", postProcessAdapter)

	newOutboxWorker := newoutbox.NewWorker(newOutboxStore, dispatchedPublisher, newoutbox.DefaultWorkerConfig())

	interactionPublisher := &noopPublisher{}
	dispatchedPublisher.Register("interaction.completed", interactionPublisher)
	dispatchedPublisher.Register("interaction.state_changed", interactionPublisher)
	dispatchedPublisher.Register("interaction.runtime_assembled", interactionPublisher)
	orch := interaction.NewOrchestratorWithStores(orchCfg, chatSvc.(interaction.MessageProcessor), tracker, newOutboxStore)
	if temporalSvc.FeatureFlags().RelationshipTimeEnabled {
		orch.SetRelationshipTimeCoordinator(relTimeCoordinator)
		chatSvc.SetRelationshipTimeCoordinator(relTimeCoordinator)
	}
	runtimeRegistry := newRuntimeContextLoaderRegistry(ctx, charRepo, temporalSvc)
	runtimePipeline := interaction.NewRuntimePipeline(runtimeRegistry, interaction.NewPathClassifier(), interaction.NewTokenBudgetManager(2400))
	runtimePipeline.SetPersonalityCompiler(personality.NewCompiler(personality.DefaultCompilerConfig()))
	runtimePipeline.SetSafetyGovernor(safety.NewGovernor(safety.DefaultGovernorConfig()))
	runtimePipeline.SetBeliefResolver(belief.ResolveBelief)
	runtimePipeline.SetAppraisalEngine(appraisal.NewEngine(appraisal.DefaultAppraisalConfig()))
	runtimePipeline.SetBudgetController(budget.NewBudgetController(0.5))
	runtimePipeline.SetDecisionLayer(decision.DefaultCandidateRegistry(), decision.DefaultArbitrationLayer())
	orch.SetRuntimePipeline(runtimePipeline)
	deadlineCfg := mindruntime.DefaultDeadlineConfig
	deadlineCfg.TotalTimeout = 180 * time.Second
	deadlineCfg.GenerationTimeout = 120 * time.Second
	dp := mindruntime.NewDeadlinePropagator(deadlineCfg)
	orch.SetDeadlineProvider(func(ctx context.Context, requestID string) (context.Context, context.CancelFunc) {
		return dp.ContextWithDeadline(ctx, requestID, mindruntime.DeadlineStageGeneration)
	})
	resolver := interaction.NewScopeResolverWithDefaultChar(interaction.NewConversationScopeBindingLookup(ctx.DB), &defaultCharacterProvider{repo: charRepo})
	dataLifecycle := mindruntime.NewDataLifecycleCoordinator(ctx.DB)
	if err := dataLifecycle.InitSchema(); err != nil {
		log.Error("failed to init data lifecycle schema:", err)
		panic("failed to init data lifecycle schema")
	}
	dataLifecycle.SetOutboxCleanupExecutor(mindruntime.NewDefaultOutboxCleanupExecutor(ctx.DB, graphSvc))
	if coordinatorSetter, ok := interface{}(memSvc).(interface {
		SetDataLifecycleCoordinator(*mindruntime.DataLifecycleCoordinator)
	}); ok {
		coordinatorSetter.SetDataLifecycleCoordinator(dataLifecycle)
	}
	if coordinatorSetter, ok := interface{}(profSvc).(interface {
		SetDataLifecycleCoordinator(*mindruntime.DataLifecycleCoordinator)
	}); ok {
		coordinatorSetter.SetDataLifecycleCoordinator(dataLifecycle)
	}
	if coordinatorSetter, ok := interface{}(epiSvc).(interface {
		SetDataLifecycleCoordinator(*mindruntime.DataLifecycleCoordinator)
	}); ok {
		coordinatorSetter.SetDataLifecycleCoordinator(dataLifecycle)
	}
	chatSvc.EnsureChannelConversation("wechat")
	chatSvc.EnsureChannelConversation("qq")

	entry := interaction.NewUnifiedEntry(orch, resolver, temporal.SystemClock{})
	compSvc.AttachUnifiedEntry(entry)
	compSvc.AttachDeliveryStore(deliveryStore)
	if coordinatorSetter, ok := interface{}(compSvc).(interface {
		SetDataLifecycleCoordinator(*mindruntime.DataLifecycleCoordinator)
	}); ok {
		coordinatorSetter.SetDataLifecycleCoordinator(dataLifecycle)
	}
	reconciliationEngine := mindruntime.NewReconciliationEngine(mindruntime.DefaultReconciliationConfig())
	graphReconAdapter := &graphReconciliationAdapter{graphSvc: graphSvc}
	qdrantReconAdapter := &qdrantReconciliationAdapter{qdrantClient: qdrant.NewQdrantClient()}
	if err := mindruntime.RegisterRuntimeReconciliationCheckers(reconciliationEngine, ctx.DB, graphReconAdapter, qdrantReconAdapter); err != nil {
		log.Warn("reconciliation checkers registration warning: ", err)
	}
	cbRegistry := mindruntime.NewCircuitBreakerRegistry()
	cbRegistry.Register("qdrant", mindruntime.DefaultCircuitBreakerConfig())
	cbRegistry.Register("surrealdb", mindruntime.DefaultCircuitBreakerConfig())
	cbRegistry.Register("model_api", mindruntime.DefaultCircuitBreakerConfig())
	voiceEntry := interaction.NewVoiceEntryWithUnifiedEntry(orch, entry)
	if err := deliveryStore.InitSchema(); err != nil {
		log.Error("failed to init delivery store schema:", err)
		panic("failed to init delivery store schema")
	}
	configureWorkflowHost(extensionRuntime, chatSvc, memSvc, deliveryStore, kernelContainer.HostEventEmitter)
	mcpRepository := mcp.NewRepository(ctx.DB)
	mcpDuplicateStore := mcp.NewDuplicateStore(ctx.DB)
	kernelContainer.MCPDuplicateProvider = &mcpDuplicateMetricAdapter{store: mcpDuplicateStore}
	mcpStorageDir := mcpDataDirectory(ctx)
	secretStore, err := mcpauth.NewEncryptedFileStore(filepath.Join(mcpStorageDir, "mcp-secrets.json"), filepath.Join(mcpStorageDir, "mcp-secrets.key"))
	if err != nil {
		panic("failed to initialize MCP secret store")
	}
	oauthManager := mcpauth.NewManager(nil, secretStore, mcpRepository)
	connectionManager := mcpmanager.New(mcpRepository, mcpmanager.DefaultFactory{Repository: mcpRepository, Secrets: secretStore, OAuth: oauthManager}, mcpmanager.Config{Connection: mcpclient.Config{ClientInfo: protocol.Implementation{Name: "amitia", Title: "Amitia", Version: "1.0.0"}, Capabilities: protocol.ClientCapabilities{Roots: map[string]any{"listChanged": true}, Sampling: map[string]any{}, Elicitation: map[string]any{}, Tasks: map[string]any{}}}})
	discoveryService := mcpdiscovery.New(mcpRepository, connectionManager)
	skillRuntime := mcpskill.New(mcpRepository, extensionRuntime, mcpskill.WithToolFacadeSyncer(newMCPToolFacadeSyncerAdapter(toolFacade)), mcpskill.WithDuplicateRecorder(mcpDuplicateStore))
	featureService := mcpfeatures.New(mcpRepository, connectionManager)
	interactionBroker := mcphost.NewBroker(chatSvc)
	hostService := mcphost.New(mcpRepository, connectionManager, mcphost.NewConfiguredRoots(mcpRepository), interactionBroker, interactionBroker)
	dependencyService := mcpdependency.New(mcpRepository, connectionManager, discoveryService, skillRuntime)
	extensionRuntime.AgentSkills.SetAfterRemove(func(ctx context.Context, extensionID string) {
		_, _ = dependencyService.Uninstall(ctx, extensionID)
	})
	connectionManager.RegisterReadyHandler(func(readyCtx context.Context, serverID string) {
		hostService.Attach(serverID)
		if discoverErr := discoveryService.Discover(readyCtx, serverID); discoverErr != nil {
			log.Warn("MCP capability discovery failed server=", serverID, " error=", discoverErr)
			return
		}
		mcpPayload, _ := json.Marshal(map[string]interface{}{
			"serverId":    serverID,
			"status":      "connected",
			"connectedAt": time.Now().UTC().Format(time.RFC3339),
		})
		mcpOpts := event.PublishOptions{
			AggregateType: "mcp_server",
			AggregateID:   serverID,
		}
		if kernelContainer.HostEventEmitter != nil {
			_, _ = kernelContainer.HostEventEmitter.EmitMCPConnectionChanged(readyCtx, mcpPayload, mcpOpts)
		}
		if registerErr := skillRuntime.RegisterServer(readyCtx, serverID); registerErr != nil {
			log.Warn("MCP skill registration failed server=", serverID, " error=", registerErr)
		}
	})
	if err := skillRuntime.RegisterAll(context.Background()); err != nil {
		log.Warn("MCP skill restore warning: ", err)
	}
	if err := connectionManager.Restore(context.Background()); err != nil {
		log.Warn("MCP connection restore warning: ", err)
	}
	kernelContainer.WireMCPAdapter(makeKernelMCPCaller(connectionManager), makeKernelMCPHealth(connectionManager), newMCPPostProcessor(mcpRepository))
	desktopPetRepo := desktoppet.NewRepository(ctx.DB, ctx)
	desktopPetRegistry := desktoppet.NewProviderRegistry()
	desktopPetWorker := worker.NewWorker(ctx.DB, desktopPetRepo, desktopPetRegistry)
	processingRepo := processing.NewRepository(ctx.DB, ctx)
	processingDataDir := mcpDataDirectory(ctx)

	bgRegistry := backgroundremoval.NewRegistry()
	if err := bgRegistry.Register(local.NewLocalProvider(), local.LocalCapabilities()); err != nil {
		log.Error("register local background provider failed: ", err)
	}

	processingPipeline := application.NewPipeline(bgRegistry, processingDataDir)
	artifactSourceAdapter := application.NewRepoArtifactSourceAdapter(processingRepo)
	processingSourceResolver := application.NewRepoSourceResolver(processingRepo, processingDataDir, artifactSourceAdapter)
	processingWorker := processingworker.NewWorker(ctx.DB, processingRepo, processingDataDir, processingPipeline, processingSourceResolver)

	qualityBridge := bridge.NewProcessingBridge(ctx.DB, processingDataDir)
	qualitySvc, err := quality.NewQualityService(quality.ServiceConfig{
		DB:             ctx.DB,
		DataDir:        processingDataDir,
		MeasurementSrc: quality.NewProcessingMeasurementAdapter(qualityBridge, processingDataDir),
		Detectors:      detectors.NewDefaultDetectors(),
		EventPublisher: quality.NewLogEventPublisher(),
	})
	if err != nil {
		log.Error("failed to create quality service: ", err)
	}
	qualityWorker := qualityworker.NewWorker(ctx.DB, qualitySvc, processingDataDir)

	processingWorker.SetOnActionProcessed(func(taskID, actionID, actionKey string) {
		if qualitySvc == nil {
			return
		}
		revisionID := ""
		revision, revErr := processingRepo.GetActiveRevision(actionID)
		if revErr != nil {
			log.Error(fmt.Sprintf("get active revision for action %s failed: %v", actionKey, revErr))
		} else if revision != nil {
			revisionID = revision.ID
		}
		_, evalErr := qualitySvc.CreateEvaluation(context.Background(), quality.CreateEvaluationRequest{
			ProcessingTaskID:   taskID,
			ProcessingActionID: actionID,
			ActionRevisionID:   revisionID,
			ActionKey:          actionKey,
		})
		if evalErr != nil {
			log.Error(fmt.Sprintf("create quality evaluation for action %s failed: %v", actionKey, evalErr))
		}
	})

	installationRepo := installation.NewRepository(ctx.DB, ctx)
	installationInstaller := installation.NewInstaller(installationRepo, processingRepo, charRepo, processingDataDir)
	installationUninstaller := installation.NewUninstaller(installationRepo, processingDataDir)

	runtimeConfig := runtime.DefaultRuntimeConfig()
	if config.AppCfg.DesktopPetRuntime.Enabled {
		runtimeConfig.Enabled = config.AppCfg.DesktopPetRuntime.Enabled
		runtimeConfig.LoopbackOnly = config.AppCfg.DesktopPetRuntime.LoopbackOnly
		runtimeConfig.HeartbeatIntervalMs = config.AppCfg.DesktopPetRuntime.HeartbeatIntervalMs
		runtimeConfig.HeartbeatTimeoutMs = config.AppCfg.DesktopPetRuntime.HeartbeatTimeoutMs
		runtimeConfig.MaxMessageBytes = config.AppCfg.DesktopPetRuntime.MaxMessageBytes
		runtimeConfig.RegisterTimeoutSec = config.AppCfg.DesktopPetRuntime.RegisterTimeoutSec
		runtimeConfig.SendQueueSize = config.AppCfg.DesktopPetRuntime.SendQueueSize
		runtimeConfig.CommandTimeoutSec = config.AppCfg.DesktopPetRuntime.CommandTimeoutSec
		runtimeConfig.MaxRetryAttempts = config.AppCfg.DesktopPetRuntime.MaxRetryAttempts
		runtimeConfig.RetryBaseDelayMs = config.AppCfg.DesktopPetRuntime.RetryBaseDelayMs
		runtimeConfig.RetryMaxDelayMs = config.AppCfg.DesktopPetRuntime.RetryMaxDelayMs
		runtimeConfig.CommandRetentionHours = config.AppCfg.DesktopPetRuntime.CommandRetentionHours
	}

	runtimeCmdStore := runtime.NewCommandStore(ctx.DB)
	runtimeStateStore := runtime.NewStateStore(ctx.DB)
	runtimeSnapshotBuilder := runtime.NewSnapshotBuilder(installationRepo, config.AppCfg.Storage.DataDir)
	runtimeSinkHolder := &runtimeEventSinkHolder{}
	desktopPetRuntime := runtime.NewService(runtimeConfig, runtimeCmdStore, runtimeStateStore, runtimeSnapshotBuilder, runtimeSinkHolder)

	installationService := installation.NewService(installationRepo, installationInstaller, installationUninstaller, processingRepo, charRepo, processingDataDir, installation.WithRuntimeNotifier(desktopPetRuntime.Notifier()))

	editingRepo := editing.NewRepository(ctx.DB)
	editingAssetStore := editing.NewAssetStore(processingDataDir, editingRepo)
	editingGenAdapter := editing.NewGenerationAdapter(ctx)
	editingProcAdapter := editing.NewProcessingAdapter(ctx)
	editingQualAdapter := editing.NewQualityAdapter(ctx)
	editingSvc := editing.NewService(editingRepo, editingAssetStore, editingGenAdapter, editingProcAdapter, editingQualAdapter, ctx.DB, processingDataDir)
	if err := editingSvc.RecoverPendingJournals(context.Background()); err != nil {
		log.Warn("editing journal recovery warning: ", err)
	}
	if err := editingSvc.ExpireSessions(context.Background()); err != nil {
		log.Warn("editing session expiry warning: ", err)
	}

	processingWorker.SetRevisionPromoter(func(processingTaskID, actionKey, userID string) error {
		_, err := editingSvc.ImportLegacyRevision(context.Background(), processingTaskID, actionKey, userID)
		return err
	})

	releaseStorage := installation.NewReleaseStorage(processingDataDir)
	revisionSource := installation.NewRevisionSourceAdapter(ctx, editingRepo, editingSvc, processingDataDir)
	releaseService := installation.NewReleaseService(installationRepo, releaseStorage, revisionSource, processingRepo, charRepo, desktopPetRuntime.Notifier(), ctx)
	if err := releaseService.RecoverPendingOperations(); err != nil {
		log.Warn("installation coordinator recovery warning: ", err)
	}

	var behaviorSvc *behavior.BehaviorService
	behaviorAssembled, assembleErr := wiring.AssembleBehavior(wiring.AssemblyDeps{
		DB:              ctx.DB,
		RuntimeService:  desktopPetRuntime,
		InstallRepo:     installationRepo,
		PsycheStore:     psycheStore,
		DataDir:         processingDataDir,
		ShadowMode:      false,
		RuntimeCmdOn:    true,
	})
	if assembleErr != nil {
		log.Error("failed to assemble behavior engine: ", assembleErr)
	} else {
		behaviorSvc = behaviorAssembled.Service
		runtimeSinkHolder.Set(NewBehaviorRuntimeEventSink(installationRepo, behaviorAssembled.Engine))
	}

	return &AppServices{
		Graph:               graphSvc,
		ChatDeliveryAdapter: deliveryAdapter,
		Memory:              memSvc,
		Profile:             profSvc,
		Episodic:            epiSvc,
		WorldBook:           wbSvc,
		Vision:              visionSvc,
		Companion:           compSvc,
		Chat:                chatSvc,
		UnifiedEntry:        entry,
		DataLifecycle:       dataLifecycle,
		RuntimeQueue:        runtimeQueue,
		NewOutbox:           newOutboxStore,
		DeliveryStore:       deliveryStore,
		DeliveryWorker:      deliveryWorker,
		OutboxWorker:        newOutboxWorker,
		DesktopPetWorker:    desktopPetWorker,
		ProcessingWorker:    processingWorker,
		QualityService:      qualitySvc,
		QualityWorker:       qualityWorker,
		InstallationService: installationService,
		ReleaseService:      releaseService,
		DesktopPetRuntime:   desktopPetRuntime,
		EditingService:      editingSvc,
		BehaviorService:     behaviorSvc,
		Reconciliation:      reconciliationEngine,
		CircuitBreakers:     cbRegistry,
		VoiceEntry:          voiceEntry,
		Extension:           extensionRuntime,
		KernelContainer:     kernelContainer,
		Emote:               emoteSvc,
		Temporal:            temporalSvc,
		RelTimeCoordinator:  relTimeCoordinator,
		MCPRepository:       mcpRepository,
		MCPConnections:      connectionManager,
		MCPAuth:             oauthManager,
		MCPDiscovery:        discoveryService,
		MCPSkills:           skillRuntime,
		MCPSecrets:          secretStore,
		MCPFeatures:         featureService,
		MCPHost:             hostService,
		MCPInteractions:     interactionBroker,
		MCPDependencies:     dependencyService,
	}
}

func mcpDataDirectory(ctx *app.AppContext) string {
	if config.AppCfg != nil && strings.TrimSpace(config.AppCfg.Storage.DataDir) != "" {
		return config.AppCfg.Storage.DataDir
	}
	var databases []struct {
		Name string `gorm:"column:name"`
		File string `gorm:"column:file"`
	}
	if ctx != nil && ctx.DB != nil && ctx.DB.Raw("PRAGMA database_list").Scan(&databases).Error == nil {
		for _, database := range databases {
			if database.Name == "main" && strings.TrimSpace(database.File) != "" {
				return filepath.Dir(database.File)
			}
		}
	}
	return filepath.Join(".", "data")
}

func configureWorkflowHost(runtime *extension.Runtime, chatSvc chat.Service, memSvc memory.Service, deliveryStore *delivery.SQLiteDeliveryStore, hostEmitter event.HostEventEmitter) {
	runtime.WorkflowHost.Schedule = wrapWithWorkflowEvent(hostEmitter, "schedule", func(ctx context.Context, input json.RawMessage, scope extension.ExecutionScope) (json.RawMessage, []extension.SideEffectRecord, error) {
		var payload map[string]interface{}
		if err := json.Unmarshal(input, &payload); err != nil {
			return nil, nil, fmt.Errorf("日程参数无效: %w", err)
		}
		if payload["due_time"] == nil && payload["dueAt"] != nil {
			payload["due_time"] = payload["dueAt"]
		}
		idempotencyKey, _ := payload["idempotencyKey"].(string)
		normalized, _ := json.Marshal(payload)
		registered, err := runtime.Registry.Get(ctx, "dev.amitia.skill.create-schedule")
		if err != nil {
			return nil, nil, err
		}
		result, err := registered.Handler(ctx, extension.ExecuteSkillRequest{SkillID: registered.Definition.ID, Input: normalized, Scope: scope, IdempotencyKey: idempotencyKey})
		return result.Output, result.SideEffects, err
	})
	runtime.WorkflowHost.Notification = wrapWithWorkflowEvent(hostEmitter, "notification", func(_ context.Context, input json.RawMessage, scope extension.ExecutionScope) (json.RawMessage, []extension.SideEffectRecord, error) {
		var payload struct {
			Content string `json:"content"`
		}
		if err := json.Unmarshal(input, &payload); err != nil {
			return nil, nil, fmt.Errorf("通知参数无效: %w", err)
		}
		payload.Content = strings.TrimSpace(payload.Content)
		if payload.Content == "" || len([]rune(payload.Content)) > 4000 {
			return nil, nil, fmt.Errorf("通知内容长度必须为 1 到 4000 个字符")
		}
		conversation, err := chatSvc.GetConversation(scope.ConversationID)
		if err != nil {
			return nil, nil, err
		}
		if conversation.CharacterID != scope.CharacterID || conversation.Channel != scope.Channel || conversation.PeerID == "" {
			return nil, nil, fmt.Errorf("通知只能发送到当前角色和会话绑定的渠道")
		}
		body, _ := json.Marshal(map[string]string{"content": payload.Content})
		interactionID := scope.RequestID
		if interactionID == "" {
			interactionID = uuid.New().String()
		}
		intent := delivery.NewDeliveryIntent(interactionID, conversation.Channel, conversation.PeerID, "text", body)
		if err := deliveryStore.CreateIntent(intent); err != nil {
			return nil, nil, err
		}
		output, _ := json.Marshal(map[string]string{"intentId": intent.ID, "status": string(intent.Status)})
		return output, []extension.SideEffectRecord{{Type: "notification_send", TargetID: intent.ID, Confirmed: true}}, nil
	})
	runtime.WorkflowHost.MemoryCandidate = wrapWithWorkflowEvent(hostEmitter, "memory_candidate", func(_ context.Context, input json.RawMessage, scope extension.ExecutionScope) (json.RawMessage, []extension.SideEffectRecord, error) {
		var payload struct {
			Key        string `json:"key"`
			Value      string `json:"value"`
			MemoryType string `json:"memoryType"`
			Importance int    `json:"importance"`
			Source     string `json:"source"`
		}
		if err := json.Unmarshal(input, &payload); err != nil {
			return nil, nil, fmt.Errorf("候选记忆参数无效: %w", err)
		}
		candidate, err := memSvc.SubmitCandidate(&memory.SubmitCandidateRequest{Key: payload.Key, Value: payload.Value, MemoryType: payload.MemoryType, Importance: payload.Importance, SourceText: payload.Source, ConversationID: scope.ConversationID, CharacterID: scope.CharacterID})
		if err != nil {
			return nil, nil, err
		}
		output, _ := json.Marshal(map[string]interface{}{"candidateId": candidate.ID, "status": "pending_review"})
		return output, []extension.SideEffectRecord{{Type: "memory_candidate_write", TargetID: candidate.ID, Confirmed: true}}, nil
	})
	runtime.WorkflowHost.ContextContribution = wrapWithWorkflowEvent(hostEmitter, "context_contribution", func(_ context.Context, input json.RawMessage, scope extension.ExecutionScope) (json.RawMessage, []extension.SideEffectRecord, error) {
		var payload struct {
			Content    string `json:"content"`
			TokenLimit int    `json:"tokenLimit"`
		}
		if err := json.Unmarshal(input, &payload); err != nil {
			return nil, nil, fmt.Errorf("上下文贡献参数无效: %w", err)
		}
		payload.Content = strings.TrimSpace(payload.Content)
		if payload.Content == "" || payload.TokenLimit < 1 || payload.TokenLimit > 1024 || len([]rune(payload.Content)) > payload.TokenLimit*8 {
			return nil, nil, fmt.Errorf("上下文贡献超出 1024 token 宿主限制")
		}
		output, _ := json.Marshal(map[string]interface{}{"content": payload.Content, "tokenLimit": payload.TokenLimit, "conversationId": scope.ConversationID})
		return output, []extension.SideEffectRecord{{Type: "context_injection", TargetID: scope.ConversationID, Confirmed: true}}, nil
	})
}

func wrapWithWorkflowEvent(hostEmitter event.HostEventEmitter, action string, handler func(context.Context, json.RawMessage, extension.ExecutionScope) (json.RawMessage, []extension.SideEffectRecord, error)) func(context.Context, json.RawMessage, extension.ExecutionScope) (json.RawMessage, []extension.SideEffectRecord, error) {
	return func(ctx context.Context, input json.RawMessage, scope extension.ExecutionScope) (json.RawMessage, []extension.SideEffectRecord, error) {
		output, effects, err := handler(ctx, input, scope)
		if err == nil && hostEmitter != nil {
			payload, _ := json.Marshal(map[string]interface{}{
				"action":         action,
				"characterId":    scope.CharacterID,
				"conversationId": scope.ConversationID,
				"channel":        scope.Channel,
				"requestId":      scope.RequestID,
			})
			opts := event.PublishOptions{
				TraceID:     scope.TraceID,
				OperationID: scope.RequestID,
			}
			_, _ = hostEmitter.EmitWorkflowCompleted(ctx, payload, opts)
		}
		return output, effects, err
	}
}

func newRuntimeContextLoaderRegistry(ctx *app.AppContext, charRepo character.Repository, temporalServices ...*temporal.Service) *interaction.ContextLoaderRegistry {
	runtimeRegistry := interaction.NewContextLoaderRegistry()
	runtimeRegistry.Register(interaction.NewRoleRuntimeProfileContextLoader(charRepo))
	runtimeRegistry.Register(interaction.NewChannelContextLoader())
	runtimeRegistry.Register(interaction.NewConversationContextLoader(ctx.DB))
	runtimeRegistry.Register(interaction.NewPsycheContextLoader(ctx.DB))
	runtimeRegistry.Register(interaction.NewRelationshipContextLoader(ctx.DB))
	runtimeRegistry.Register(interaction.NewBeliefContextLoader(ctx.DB))
	runtimeRegistry.Register(interaction.NewLifeContextLoader(ctx.DB))
	runtimeRegistry.Register(interaction.NewNeedContextLoader(ctx.DB))
	runtimeRegistry.Register(interaction.NewUnresolvedThreadContextLoader(ctx.DB))
	if len(temporalServices) > 0 && temporalServices[0] != nil {
		runtimeRegistry.Register(interaction.NewTemporalContextLoader(temporalServices[0]))
	}
	return runtimeRegistry
}

type chatOutboxAdapter struct {
	store *newoutbox.SQLiteOutboxStore
}

func (a *chatOutboxAdapter) AppendOutbox(aggregateID, eventType string, payload []byte) error {
	record := newoutbox.OutboxRecord{
		ID:          uuid.New().String(),
		AggregateID: aggregateID,
		EventType:   eventType,
		Payload:     payload,
		Status:      newoutbox.OutboxStatusPending,
		MaxRetries:  newoutbox.DefaultMaxRetries,
		AvailableAt: time.Now(),
		CreatedAt:   time.Now(),
	}
	return a.store.Append(record)
}

func (a *chatOutboxAdapter) AppendOutboxWithKey(aggregateID, eventType, idempotencyKey string, payload []byte) error {
	record := newoutbox.OutboxRecord{
		ID:             uuid.New().String(),
		AggregateID:    aggregateID,
		EventType:      eventType,
		Payload:        payload,
		Status:         newoutbox.OutboxStatusPending,
		MaxRetries:     newoutbox.DefaultMaxRetries,
		AvailableAt:    time.Now(),
		IdempotencyKey: idempotencyKey,
		CreatedAt:      time.Now(),
	}
	return a.store.Append(record)
}

type chatDeliveryAdapter struct {
	store *delivery.SQLiteDeliveryStore
}

func (a *chatDeliveryAdapter) CreateDeliveryIntent(interactionID, channel, peerID, contentType string, payload []byte) error {
	intent := delivery.NewDeliveryIntent(interactionID, channel, peerID, contentType, payload)
	return a.store.CreateIntent(intent)
}

func (a *chatDeliveryAdapter) CreateOutputLease(interactionID, characterID, userID, channel string) error {
	lease := delivery.NewOutputLease(interactionID, characterID, userID, channel)
	return a.store.CreateLease(lease)
}

func (a *chatDeliveryAdapter) AcquireOutputLease(interactionID, characterID, userID, channel string) (string, string, error) {
	lease := delivery.NewOutputLease(interactionID, characterID, userID, channel)
	if err := a.store.CreateLease(lease); err != nil {
		return "", "", err
	}
	return lease.ID, lease.OwnerToken, nil
}

func (a *chatDeliveryAdapter) ReleaseOutputLease(leaseID, ownerToken string) error {
	return a.store.ReleaseLease(leaseID, ownerToken)
}

func (a *chatDeliveryAdapter) PreemptActiveOutputLeases(characterID string) error {
	_, err := a.store.PreemptActiveLeasesByCharacter(characterID)
	return err
}

type graphReconciliationAdapter struct {
	graphSvc graph.Service
}

func (a *graphReconciliationAdapter) Name() string { return "graph" }

func (a *graphReconciliationAdapter) CheckSideEffectExists(ctx context.Context, aggregateID, eventType string) (bool, error) {
	if a.graphSvc == nil {
		return false, nil
	}
	nodes, err := a.graphSvc.GetAllNodes(aggregateID)
	if err != nil {
		return false, err
	}
	return len(nodes) > 0, nil
}

type qdrantReconciliationAdapter struct {
	qdrantClient *qdrant.QdrantClient
}

func (a *qdrantReconciliationAdapter) Name() string { return "qdrant" }

func (a *qdrantReconciliationAdapter) CheckSideEffectExists(ctx context.Context, aggregateID, eventType string) (bool, error) {
	if a.qdrantClient == nil {
		return false, nil
	}
	_, err := a.qdrantClient.SearchWithFilter(ctx, "memory_embeddings", nil, qdrant.QdrantFilter{CharacterID: aggregateID}, 1)
	if err != nil {
		return false, nil
	}
	return true, nil
}

type postProcessPublisherAdapter struct {
	chatSvc chat.Service
}

func (a *postProcessPublisherAdapter) Publish(record newoutbox.OutboxRecord) error {
	return a.chatSvc.ReplayPostProcess(record.EventType, record.Payload)
}

type noopPublisher struct{}

func (p *noopPublisher) Publish(record newoutbox.OutboxRecord) error {
	return nil
}

type runtimeEventSinkHolder struct {
	mu   sync.Mutex
	sink runtime.RuntimeEventSink
}

func (h *runtimeEventSinkHolder) OnRuntimeEvent(ctx context.Context, event runtime.RuntimeDomainEvent) error {
	h.mu.Lock()
	sink := h.sink
	h.mu.Unlock()
	if sink == nil {
		return nil
	}
	return sink.OnRuntimeEvent(ctx, event)
}

func (h *runtimeEventSinkHolder) Set(sink runtime.RuntimeEventSink) {
	h.mu.Lock()
	h.sink = sink
	h.mu.Unlock()
}

type BehaviorRuntimeEventSink struct {
	installRepo installation.Repository
	engine      *behavior.BehaviorEngine
}

func NewBehaviorRuntimeEventSink(installRepo installation.Repository, engine *behavior.BehaviorEngine) *BehaviorRuntimeEventSink {
	return &BehaviorRuntimeEventSink{installRepo: installRepo, engine: engine}
}

func (s *BehaviorRuntimeEventSink) OnRuntimeEvent(ctx context.Context, event runtime.RuntimeDomainEvent) error {
	if s.engine == nil {
		return nil
	}
	characterID, petInstanceID := s.resolveCharacterAndPet(event)
	now := time.Now()

	switch event.EventType {
	case "clicked", "dragged":
		builder := events.NewEnvelope("desktop.pet."+event.EventType, behavior.OriginDesktop).
			UserID(event.UserID).
			CharacterID(characterID).
			PetInstanceID(petInstanceID).
			OccurredAt(event.Timestamp).
			DedupKey(events.BuildDedupKey(petInstanceID, event.EventType, fmt.Sprintf("t%d", event.Timestamp.UnixNano())))
		if len(event.Payload) > 0 {
			builder.PayloadRaw(event.Payload)
		}
		return s.engine.SubmitEvent(ctx, builder.Build(now))

	case "playback_completed", "playback_interrupted":
		phase := behavior.PlaybackCompleted
		if event.EventType == "playback_interrupted" {
			phase = behavior.PlaybackInterrupted
		}
		builder := events.NewEnvelope("playback.action."+string(phase), behavior.OriginPlayback).
			UserID(event.UserID).
			CharacterID(characterID).
			PetInstanceID(petInstanceID).
			OccurredAt(event.Timestamp).
			DedupKey(events.BuildDedupKey(event.InstallationID, string(phase), fmt.Sprintf("t%d", event.Timestamp.UnixNano())))
		if len(event.Payload) > 0 {
			var payload map[string]interface{}
			if json.Unmarshal(event.Payload, &payload) == nil {
				if v, ok := payload["commandId"].(string); ok && v != "" {
					builder.PayloadField("commandId", v)
				}
				if v, ok := payload["decisionId"].(string); ok && v != "" {
					builder.PayloadField("decisionId", v)
				}
				if v, ok := payload["actionKey"].(string); ok && v != "" {
					builder.PayloadField("actionKey", v)
				}
			}
		}
		return s.engine.SubmitEvent(ctx, builder.Build(now))
	}

	return nil
}

func (s *BehaviorRuntimeEventSink) resolveCharacterAndPet(event runtime.RuntimeDomainEvent) (string, string) {
	characterID := event.CharacterID
	petInstanceID := ""

	if len(event.Payload) > 0 {
		var payload map[string]interface{}
		if json.Unmarshal(event.Payload, &payload) == nil {
			if v, ok := payload["petInstanceId"].(string); ok && v != "" {
				petInstanceID = v
			}
		}
	}

	if characterID == "" && event.InstallationID != "" && s.installRepo != nil {
		inst, err := s.installRepo.GetInstallation(event.InstallationID)
		if err == nil && inst != nil {
			characterID = inst.CharacterID
		}
	}

	return characterID, petInstanceID
}

var _ runtime.RuntimeEventSink = (*runtimeEventSinkHolder)(nil)
var _ runtime.RuntimeEventSink = (*BehaviorRuntimeEventSink)(nil)
